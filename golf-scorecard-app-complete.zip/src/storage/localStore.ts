// IndexedDB / local storage abstraction
