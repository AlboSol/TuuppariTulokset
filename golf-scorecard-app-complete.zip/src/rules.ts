/*
 Handicap & scoring rules placeholder
*/
export function calculateNetScore(gross: number, strokes: number) {
  return gross - strokes;
}
