export const APP_NAME = "Golf Scorecard App";
