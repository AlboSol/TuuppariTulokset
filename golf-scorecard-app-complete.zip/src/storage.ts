/*
 Local storage abstraction (IndexedDB / AsyncStorage later)
*/
export const storage = {
  async get(key: string) {
    return JSON.parse(localStorage.getItem(key) || "null");
  },
  async set(key: string, value: any) {
    localStorage.setItem(key, JSON.stringify(value));
  }
};
